<?php

declare(strict_types=1);

namespace Application\Controller;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;
use Application\Model\EmpTable;
use Application\Form\EmpForm;
class IndexController extends AbstractActionController
{

    private $dbAdapter;
	
    public function __construct($db)
    {
        $this->dbAdapter = $db;
    }

    public function indexAction()
    {
        $EmpTable =   new EmpTable($this->dbAdapter);

        $EmpTable($this->dbAdapter);  
        $result = $EmpTable->select();
        return new ViewModel(['data'=>$result]);
    }

    public function addAction()
    {
        $empForm =  new EmpForm();
        //echo "<pre>"; print_r($empForm); die;
        return new ViewModel(['empForm'=>$empForm]);
    }
}