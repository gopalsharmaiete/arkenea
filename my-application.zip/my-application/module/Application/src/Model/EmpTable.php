<?php

namespace Application\Model;
 
use Laminas\Db\TableGateway\AbstractTableGateway;
use Laminas\Db\Adapter\Adapter;
use Laminas\Db\Sql\Select; 
class EmpTable extends AbstractTableGateway
{
    protected $table = 'tbl_employee';
    
    public function __invoke(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->initialize();
    }
     
}


