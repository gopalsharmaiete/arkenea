<?php
namespace Application\Form;
use Laminas\Form\Form;
use Laminas\InputFilter\InputFilter;
use Application\Entity\Post;
/**
 * This form is used to collect post data.
 */
class EmpForm extends Form
{
    /**
		* Constructor.     
	*/
    public function __construct()
	{
        // Define form name
		parent::__construct('emp-form');
		// Set POST method for this form
		$this->setAttribute('method', 'post');
		$this->addElements(); 
	}
    /**
     * This method adds elements to form (input fields and submit button).
     */
    protected function addElements() 
    {
         $this->add([        
            'type'  => 'text',
            'name' => 'name',
            'attributes' => [
                'id' => 'name',
                'class'=>'form-control'
            ],
            'options' => [
                'label' => 'Employee Name',
            ],
        ]);
        $this->add([        
            'type'  => 'text',
            'name' => 'address',
            'attributes' => [
                'id' => 'address',
                'class'=>'form-control'
            ],
            'options' => [
                'label' => 'Employee Address',
            ],
        ]);
        $this->add([        
            'type'  => 'text',
            'name' => 'email',
            'attributes' => [
                'id' => 'email',
                'class'=>'form-control'
            ],
            'options' => [
                'label' => 'Employee Email',
            ],
        ]);
        $this->add([        
            'type'  => 'number',
            'name' => 'phone',
            'attributes' => [
                'id' => 'phone',
                'class'=>'form-control'
            ],
            'options' => [
                'label' => 'Phone',
            ],
        ]);
        $this->add([        
            'type'  => 'text',
            'name' => 'dob',
            'attributes' => [
                'id' => 'dob',
                'class'=>'form-control'
            ],
            'options' => [
                'label' => 'Employee DOB',
            ],
        ]);
 
       $this->add([
			'type'  => 'submit',
			'attributes' => [                
                'value' => 'Submit',
                'id' => 'submitbutton',
            ],
        ]);
    }

}