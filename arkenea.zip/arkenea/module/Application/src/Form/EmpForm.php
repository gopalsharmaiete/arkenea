<?php

namespace Application\Form;

use Laminas\Form\Form;
use Laminas\Form\Element;

/**
* This emp form is used to collect post data.
*/

class EmpForm extends form
{


	public $form = null;
	//public $filterdata = array();
	//public $formTitle = null; 
	//public $cardSettingOptionObj = null;	
	//public $formRanderSection = null; 
	//public $formDbAdapter = null;
    
	
	public function __construct()
    {
        parent::__construct('emp-form');
		// Set POST method for this form
        $this->setAttribute('method', 'post');
        $this->setAttribute('autocomplete', 'off');
		$this->setAttribute('class', 'empForm');
		$this->setAttribute('enctype', "multipart/form-data");
		//$this->setAttribute('onSubmit', 'return checkPassword()');
        $this->employee();
        
    }
  	
    /**
     * Function : signup()
	 * Params : NULL
     * form to signup
     * */
 	public function employee() 
	{
  
		$this->add(['type'  => 'text',
						'name' => 'name',
						'attributes' => [
						'id' => 'name',
						'class'=>'form-control'],
						'options' => [
							'label' => 'Employee Name',
						],
		]);  
					
		$this->add(['type' => 'text',
						'name' => 'address',
						'attributes' => [
						'id' =>'address',
						'class'=>'form-control'
					],
					'options' => [
						'label' => 'Employee Address',
					],
						
		]);
		
		$this->add(['type' => Element\Email::class,
						'name' => 'email',
						'attributes' => [
						'id' =>'email',
						'class'=>'form-control'
					],
					'options' => [
						'label' => 'Email Address',
					],
						
		]); 
		
		$this->add(['type' => 'text',
						'name' => 'phone',
						'attributes' => [
						'id' =>'phone',
						'class'=>'form-control',
						'maxlength'=>'10',
						'minlength'=>'10',
						'pattern'=>'\d*'
					],
					'options' => [
						'label' => 'Phone',
					],
						
		]);

		$this->add(['type' => 'text',
						'name' => 'dob',
						'attributes' => [
						'id' =>'dob',
						'class'=>'form-control',
					],
					'options' => [
						'label' => 'Employee DOB',
					],
						
		]);
	 
		$this->add(['type' => 'file',
						'name' => 'emp_image',
						'attributes' => [
						'id' =>'emp_image',
						'class'=>'form-control',
						
					],
					'options' => [
							'label' => 'Employee Image',
						],
						
		]); 
		
		$this->add([
			'type' => Element\Hidden::class,
			'name' => 'id',
		]);


			// Add the CSRF field
		$this->add([
					'type' => 'csrf',
					'name' => 'csrf',
					'options' => [
					'csrf_options' => [
					'timeout' => 600
					],
				],
			]);

		$this->add([
					'type'  => 'submit',
					'name'  => 'submit',
					'attributes' => [                
					'value' => 'Submit',
					'id' => 'submit',
					'class' => 'btn btn-primary'
					],
				]);
		return $this->form;
	}

}