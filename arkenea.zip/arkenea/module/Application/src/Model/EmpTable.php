<?php

namespace Application\Model;
 
use Laminas\Db\TableGateway\AbstractTableGateway;
use Laminas\Db\Adapter\Adapter;
use Laminas\Db\Sql\Select; 
class EmpTable extends AbstractTableGateway
{

    public function __construct($adapter)
    {
    $this->table ='tbl_employee';
    $this->adapter = $adapter;
    $this->initialize();
    }


    public function fetchAll($filterData = [])
    {
        $where = 1;
        if(isset($filterData['id'])) {
            $where.= ' AND id='.$filterData['id'];
        }
        if(isset($filterData['!id'])) {
            $where.= ' AND id !='.$filterData['!id'];
        }
        if(isset($filterData['email'])) {
            $where.= ' AND email = "'.$filterData['email'].'"';
        }
        $resultSet = $this->select(function($select) use($where){
            $select->where($where);
        });
        return $resultSet->toArray();
    }

}


