<?php

namespace Application\Helper;

class  ValidationHelper 

{



	private $errors;

    private $index;

    private $data;

    private $modelObj;



	public function __construct($model = null)

	{

		$this->errors = [];

        $this->index = '';

        $this->data = '';

        $this->modelObj = $model;

    }

    /*

     * indexAction() - Method to show Customer listing

     * @access public

     * @return void

     */

    public function validate($data = [],$validator = [])

    {

        $this->errors = [];

        if(count($data) <= 0){

           return $this->errors['noData'] = 'The Data Array Can\'t Be  empty';

        }



        $this->data = $data;

    	try {

              

                foreach($validator as $index=>$value)

                 {

                    $this->index = $index;

                    self::getValidate($value);

                 }



            

			 return $this->errors; 

		} catch(\Exception $e) { 

			echo $e; die;

			$this->flashMessenger()->addErrorMessage($e->getMessage());

			//return $this->redirect()->toUrl('/admin');

		}

       

    }



    /**

     * ValidateFile()

     * @param Array $files

     * @params Array $validator 

     *      

     *  

    */



    public function validateFile($data=[],$validator = [])  {
            //return $data;
			
       $this->errors = [];

        $this->data = [];

             

          if(count($data) <=0 ) {

                return $this->errors['noData'] = 'No File Data Found';

          }



         

        

          $this->data['file'] = $data;

      



          

    



          try {



                foreach($validator as $key=>$value) {

                    

                    switch ($key) {

                        

                        case 'size':

                         

                           self::validateSize($value);

                        break;

                        

                        case 'ext':

                            self::validateExtension($value);

                        break;



                        case 'required':

                          

                           if(!isset($this->data['file']['name']) ||  $this->data['file']['name'] ==''){

                               $this->errors['file'] = 'file:File Is in the Required';

                           }

                        break;

                        

                        

                    }



                }


                   //return $vaildator; 
         return $this->errors;

                                  

          } catch(\Exception $e) {

               echo "<pre>"; var_dump($e); exit;

          } 

    } 



   /**
	 * Perform a aggrigate validation function 
	 * @param @value string 
	 * @return void  
	 */


    public function getValidate($value) 

    {

             $validators = explode('|',$value);

           

            foreach($validators as $validator) 

             {

                

                if($validator == 'required') {

                     self::validateRequired();

                 }

                
                 
                if($validator == 'email') {
                     self::validateEmail();

                 }



                 if($validator == 'alphanumeric') {

                     self::validateAlphaNumeric();

                 }



                 if(strstr($validator,'max') != false) {

                     $max = explode(':',$validator);

                     self::validateMax($max[1]);

                  }



                 if($validator == 'creditcard') {

                     self::validateCreditCard($max[1]);

                 }



                 if($validator == 'numeric') {

                    self::validateNumeric();

                 }



                 if($validator == 'url'){

                    self::validateUrl();

                 }



                if( strstr($validator,'unique') != false ) {

                    $exculde = explode(':',$validator);

                    if(isset($exculde[1])) {

                        self::validateUnique($exculde[1]);

                    } else {

                        self::validateUnique();



                    }

                    



                 }
                 if($validator == 'ip'){

                    self::validateIpAddress();

                 }

             }

    

    }


    /**
	 * Perform a email validation function
	 * @param void 
	 * @return bool  
	 */

    public function validateEmail()

     {

        $email = $this->data[$this->index];

        $emailValidator = new \Laminas\Validator\EmailAddress();



        if(!isset($email) || $email == '' ) return true;

        

        if(!$emailValidator->isValid($email)) {
           $this->errors[$this->index] = ucwords(preg_replace('/(_)+/',' ',$this->index)).' : Please Enter A Valid Email';

            return true;

        }

         

         return true;

    

    }



    /**
	 * Perform a required filed validation function
	 * @param void 
	 * @return bool  
	 */


    public function validateRequired()

     {

        $required = $this->data[$this->index];

        



        if(!isset($required) || $required == '') {



            $this->errors[$this->index] = ucwords(preg_replace('/(_)+/',' ',$this->index)).' : Value is required';

            return true;



        }



        return true;

    

    

    }

    /**
	 * Perform a max allowed filed validation function
	 * @param void 
	 * @return bool  
	 */


    public function validateMax($value)

     {

        $max = $this->data[$this->index];

        

        

        if(!isset($max) || $max == '' ) return true;

        

        if(strlen($max) > $value) {

            $this->errors[$this->index] = ucwords(preg_replace('/(_)+/',' ',$this->index)).' : The maximum length of character is '.$value;

            return true;

        }

         

         return true;

    

    }


    /**
	 * Perform a Alpha Numeric validation function
	 * @param void 
	 * @return bool  
	 */

    public function validateAlphaNumeric() 

    {

        $value = $this->data[$this->index];



        if(!isset($value) || $value == '' ) return true;



        if(!preg_match('/^[A-Za-z0-9 ]+$/',$value)) {



            $this->errors[$this->index] = ucwords(preg_replace('/(_)+/',' ',$this->index)).' : Alpha Numeric Chanracters are needed';

            return true;



        }



        return true;



    }

	/**
	 * Perform a credit card numer formate validation
	 * @param void 
	 * @return bool  
	 */

    public function validateCreditCard() {



        $value = $this->data[$this->index];



        if(!isset($value) || $value == '' ) return true;

        $cCard = new \Laminas\Validator\CreditCard();



        if(!$cCard->isValid( $value)){

            

            $this->errors[$this->index] = ucwords(preg_replace('/(_)+/',' ',$this->index)).' : Invalid credit card number';

            return true;

        }



        return true;

    }


	/**
	 * Perform a number formate validation
	 * @param void 
	 * @return bool  
	 */



    public function validateNumeric() {



        $value = $this->data[$this->index];



        if(!isset($value) || $value == '' ) return true;

       



        if(!is_numeric($value)){

            

            $this->errors[$this->index] = ucwords(preg_replace('/(_)+/',' ',$this->index)).' : Invalid Number';

            return true;

        }



        return true;

    }


	/**
	 * Perform a url formate validation
	 * @param void 
	 * @return bool  
	 */


    public function validateUrl() {



        $value = $this->data[$this->index];



        if(!isset($value) || $value == '' ) return true;

        $url = new \Laminas\Validator\Uri();



        if(!$url->isValid( $value)){

            

            $this->errors[$this->index] = ucwords(preg_replace('/(_)+/',' ',$this->index)).' : Invalid credit card number';

            return true;

        }



        return true;

    }


	/**
	 * Perform a size limit validation
	 * @param void 
	 * @return bool  
	 */
    

    public function validateSize($value = []) {

        

        

        $validator = new \Laminas\Validator\File\FilesSize([

            'min' => '1kB',  

            'max' => $value[0],

        ]);

        

        if (!$validator->isValid($this->data)) {

            $this->errors[$this->index] = 'File:Invalid File Size The Size Must Be Less Then '.$value[0];

            return true;

        }

             

    

    }

	/**
	 * Perform a unique filed validation
	 * @param $exculde string 
	 * @return bool  
	 */

    public function validateUnique($exculde = '') {

  

         

        if($this->modelObj != null) {

            $data[$this->index] = $this->data[$this->index];



               if($exculde != '') {

                   $data['!'.$exculde] = $this->data[$exculde];

               }
               
                $result = $this->modelObj->fetchAll($data);
                

               if(count($result) > 0){

                    $this->errors[$this->index] = ucwords(preg_replace('/(_)+/',' ',$this->index)).' : Alreay Exist in the Database';

                    return true;

                 }



                 return true;

             }



             $this->errors[$this->index] = ucwords(preg_replace('/(_)+/',' ',$this->index)).' : Please Pass Model Object in Validation Constructor To use Unique';

             return true;



    }

	/**
	 * Perform a unique filed validation
	 * @param $value array 
	 * @return bool  
	 */

    public function validateExtension($value = []) {

        

        $validator = new \Laminas\Validator\File\Extension(['extension' => $value]);

    

        if (!$validator->isValid($this->data['file'])) {

            $this->errors[$this->index] = ucwords(preg_replace('/(_)+/',' ',$this->index)).' : Invalid File Extensions allowed are:'.implode(',',$value);

            return true;

        }

             

    

    }

 
    /*
     * validateIpAddress() - Method to check Ip address validation 
     * @access public
     * @return true
     */
    public function validateIpAddress() {
        $value = $this->data[$this->index];
        if(!isset($value) || $value == '' ) return true;
        $ipValidator = new \Laminas\Validator\Ip();
        if(!$ipValidator->isValid( $value)){
            $this->errors[$this->index] = ucwords(preg_replace('/(_)+/',' ',$this->index)).' : Invalid ip address formate';
            return true;
        }
        return true;
    }




}

