<?php
namespace Application\Controller\Factory;
use Interop\Container\ContainerInterface;
use Application\Controller\IndexController;
use Laminas\ServiceManager\Factory\FactoryInterface;

/**
 * This is the factory for IndexController. Its purpose is to instantiate the controller
 * and inject dependencies into its constructor.
**/
class IndexControllerFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
	{
		
		$db = $container->get('Laminas\Db\Adapter\Adapter');
		return new IndexController($db);
    }
}
