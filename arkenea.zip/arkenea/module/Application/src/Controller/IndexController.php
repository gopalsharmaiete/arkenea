<?php

declare(strict_types=1);

namespace Application\Controller;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;
use Application\Model\EmpTable;
use Application\Form\EmpForm;
use Application\Helper\ValidationHelper;
use Laminas\Paginator\Adapter;
use Laminas\Paginator\Paginator;
class IndexController extends AbstractActionController
{

    private $dbAdapter;
    private $formObj;
    private $modelObj;
    public $errors;
    public $defaultPageCount = 2;
	
    public function __construct($db)
    {
        $this->modelObj =   new EmpTable($db);
        
    }

    public function indexAction()
    {  
        try{
            $result = $this->modelObj->fetchAll();
            $paginator = new Paginator(new Adapter\ArrayAdapter($result));
            $paginator->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
            $paginator->setItemCountPerPage($this->defaultPageCount);
            return new ViewModel(['paginator'=>$paginator]);
        } catch (\Exception $e){
            echo $e->getMessage(); exit;
        }
    }

    public function saveAction()
    {
      try{
        $empForm =  new EmpForm();
        $routeID = $this->params()->fromRoute('id');
        $pageTitle = (isset($routeID) && !empty($routeID))?"Edit Employee":"Add Employee";
        
        $session = new \Laminas\Session\Container();

        // Create the validator
        $validator = new \Laminas\Validator\Csrf([
            'session' => $session,
        ]);
        $hash = $validator->getHash();

        if($this->getRequest()->isPost() && $validator->isValid($hash)) {
            $validate = new ValidationHelper($this->modelObj);
            $data = $this->params()->fromPost();
            unset($data['csrf']);
            unset($data['submit']);
            $id = $data['id'];
            $validationArray = ['name'=>'required','address'=>'required','dob'=>'required','phone' => 'required|numeric'];
            if(isset($id) && !empty($id)){ 
                $validationArray['email'] = 'required|email|unique:id';
            }else{
                $validationArray['email'] = 'required|email|unique';
            }
            
            $this->errors[] = $validate->validate($data,$validationArray);
            
            if(strtotime($data['dob']) > strtotime(date('y-m-d'))){
                $this->errors[0]['dob'] = "Date of birth is not accepted greater than today.";
            }
            if(strlen($data['phone']) != 10 && is_numeric($data['phone'])){
                $this->errors[0]['phone'] = "Phone is accepted only 10 digit";
            }
            $files = $this->params()->fromFiles('emp_image');
            $fileError =[];
            if(isset($files['name']) && $files['name'] != '')
              {
                $fileError = $validate->validateFile($files,['ext' => ['png','jpeg','jpg']]);
                //echo "<pre>"; print_r($fileError); die;
                if(count($fileError)>0){
                $this->errors[0]['emp_image'] = str_replace('Email : ','Image : ',$fileError['email']);
                }
                 
            }
            
            if(isset($this->errors[0]) && count($this->errors[0])>0){
                $empForm->setData($data);
                return new ViewModel(['partialForm'=>$empForm,'pageTitle'=>$pageTitle,'errors' => $this->errors[0]]);
            } 
            
            if(!isset($this->errors[0]['emp_image'])) 
            {
                
                $uploads = $_SERVER['DOCUMENT_ROOT']."/arkenea/public/img/";
                $ext = explode('.',$files['name']);
                   
                $filename = time().'.'.end($ext);
                $uploads .= $filename;
                $data['emp_image'] = $filename;
                move_uploaded_file($files['tmp_name'], $uploads);
            }
            //echo "<pre>"; print_r($this->errors); die;
            unset($data['id']);
            if(isset($id) && !empty($id)){
                $this->modelObj->update($data,'id='.$id);
                $this->flashMessenger()->addSuccessMessage('Employee data successfully updated.');
            }else{
                $this->modelObj->insert($data);
                $this->flashMessenger()->addSuccessMessage('Employee has added successfully.');
            }
            
			return $this->redirect()->toRoute('home');
        }else{
            $routeID = $this->params()->fromRoute('id');
            if(isset($routeID) && !empty($routeID)){
                $results = $this->modelObj->fetchAll(['id' => $routeID]);
                $empForm->setData($results[0]);
            }
        }
        return new ViewModel(['partialForm'=>$empForm,'pageTitle'=>$pageTitle]);
    } catch (\Exception $e){
        echo $e->getMessage(); exit;
    }       
        

    }


    public function deleteAction()
    {
        try {
                $id = $this->params()->fromRoute('id');
                $validate = new ValidationHelper($this->modelObj);
                $this->errors = $validate->validate(['id' => $id],['id' => 'required|numeric']);
                
                if(count($this->errors) > 0)
                {
                    $this->flashMessenger()->addErrorMessage('Invalid Id passed! please try again');
                    return $this->redirect()->toRoute('home');
                }
                $this->modelObj->delete('id='.$id);
            
                $this->flashMessenger()->addSuccessMessage('Employee Deleted successfully');
                return $this->redirect()->toRoute('home');
        
        } catch (\Exception $e){
            echo $e->getMessage(); exit;
        }
    }

}